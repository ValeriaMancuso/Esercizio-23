var estratto: number;
estratto = Math.floor((Math.random() * (100 - 1)) + 1);
console.log(`Numero casuale: ${estratto}`);

var giocatore1: number;
var giocatore2: number;

giocatore1 = Math.floor((Math.random() * (100 - 1)) + 1);
giocatore2 = Math.floor((Math.random() * (100 - 1)) + 1);
console.log(`Numero Giocatore 1: ${giocatore1}`);
console.log(`Numero Giocatore 2: ${giocatore2}`);


if (giocatore1 == estratto) {
    console.log('Il Giocatore 1 ha indovinato');
} else if (giocatore2 == estratto) {
    console.log('Il Giocatore 2 ha indovinato');
}
else if (Math.abs(giocatore1 - estratto) < Math.abs(giocatore2 - estratto)) {
    console.log('Nessuno dei due giocatori ha indovinato, ma il giocatore 1 si è avvicinato di più');
} else {
    console.log('Nessuno dei due giocatori ha indovinato, ma il giocatore 2 si è avvicinato di più');
}